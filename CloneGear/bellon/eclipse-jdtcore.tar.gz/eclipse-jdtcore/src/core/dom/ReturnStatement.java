/*******************************************************************************
 * Copyright (c) 2001 International Business Machines Corp. and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v0.5 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v05.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.jdt.core.dom;
/**
 * Return statement AST node type.
 *
 * <pre>
 * ReturnStatement:
 *    <b>return</b> [ Expression ] <b>;</b>
 * </pre>
 * 
 * @since 2.0
 */
public class ReturnStatement extends Statement {
       /**
        * The expression; <code>null</code> for none; defaults to none.
        */
       private Expression optionalExpression = null;
       /**
        * Creates a new AST node for a return statement owned by the 
        * given AST. By default, the statement has no expression.
        * 
        * @param ast the AST that is to own this node
        */
       ReturnStatement(AST ast) {
             super(ast); }
       /* (omit javadoc for this method)
        * Method declared on ASTNode.
        */
       ASTNode clone(AST target) {
             ReturnStatement result = new ReturnStatement(target);
             result.setLeadingComment(getLeadingComment());
             result.setExpression(
                  (Expression) ASTNode.copySubtree(target, getExpression()));
             return result; }
       /* (omit javadoc for this method)
        * Method declared on ASTNode.
        */
       boolean equalSubtrees(Object other) {
             if (!(other instanceof ReturnStatement)) {
                  return false; }
             ReturnStatement o = (ReturnStatement) other;
             return ASTNode.equalNodes(getExpression(), o.getExpression()); }
       /* (omit javadoc for this method)
        * Method declared on ASTNode.
        */
       void accept0(ASTVisitor visitor) {
             boolean visitChildren = visitor.visit(this);
             if (visitChildren) {
                  acceptChild(visitor, getExpression()); }
             visitor.endVisit(this); }
       /**
        * Returns the expression of this return statement, or 
        * <code>null</code> if there is none.
        * 
        * @return the expression node, or <code>null</code> if there is none
        */ 
       public Expression getExpression() {
             return optionalExpression; }
       /**
        * Sets or clears the expression of this return statement.
        * 
        * @param expression the expression node, or <code>null</code> if 
        *    there is none
        * @exception $precondition-violation:different-ast$
        * @exception $precondition-violation:not-unparented$
        * @exception $postcondition-violation:ast-cycle$
        */ 
       public void setExpression(Expression expression) {
             // a ReturnStatement may occur inside an Expression - must check cycles
             replaceChild(this.optionalExpression, expression, true);
             this.optionalExpression = expression; }
       /* (omit javadoc for this method)
        * Method declared on ASTNode.
        */
       int memSize() {
             return super.memSize() + 1 * 4; }
       /* (omit javadoc for this method)
        * Method declared on ASTNode.
        */
       int treeSize() {
             return
                  memSize()
                  + (optionalExpression == null ? 0 : getExpression().treeSize()); } }
