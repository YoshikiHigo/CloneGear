/* cumtvt */
long int cmprec;
long int cmpoll;
long int cmreg;
char cmdate[12];
char cmtime[8];
long int cumt[MAXCAND];
char cmelec[50];
int prfini[MAXPRECINCT];       /* logical */
long int prpoll[MAXPRECINCT];
