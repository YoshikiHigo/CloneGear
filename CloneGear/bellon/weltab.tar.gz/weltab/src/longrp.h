/* longrp */
char longrep[131],headc[131];
