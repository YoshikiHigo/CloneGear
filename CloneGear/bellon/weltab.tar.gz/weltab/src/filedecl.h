/* file declarations */
FILE *flunitinfo, *filereport;
FILE *fileoffices, *flglobal, *floffice, *flprecinfo;
FILE *floffnam, *fldualoff, *flcand, *fldualcand;
FILE *filevotes, *flprecid, *flprecvote;
FILE *fltotals;
