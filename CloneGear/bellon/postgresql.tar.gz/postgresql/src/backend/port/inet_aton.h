/* $Id: inet_aton.h,v 1.7 1998/02/26 04:34:08 momjian Exp $ */
int         inet_aton(const char *cp, struct in_addr * addr);
