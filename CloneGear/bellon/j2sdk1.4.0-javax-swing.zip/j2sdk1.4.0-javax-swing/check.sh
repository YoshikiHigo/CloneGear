#!/bin/bash
javac -nowarn -classpath .:../rt.jar $(find -name "*.java")
