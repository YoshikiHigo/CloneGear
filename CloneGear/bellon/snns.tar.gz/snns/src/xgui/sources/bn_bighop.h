/*****************************************************************************
  FILE           : $Source: /projects/higgs1/SNNS/CVS/SNNS/xgui/sources/bn_bighop.h,v $
  SHORTNAME      : bn_bighop
  SNNS VERSION   : 4.2
  PURPOSE        : 
  NOTES          :
  AUTHOR         : Christine Bagdi 
  DATE           : 27.5.1993
  CHANGED BY     : 
  RCS VERSION    : $Revision: 2.6 $
  LAST CHANGE    : $Date: 1998/02/25 15:19:43 $
    Copyright (c) 1990-1995  SNNS Group, IPVR, Univ. Stuttgart, FRG
    Copyright (c) 1996-1998  SNNS Group, WSI, Univ. Tuebingen, FRG
******************************************************************************/
#ifndef _BN_BIGHOP_DEFINED_
#define  _BN_BIGHOP_DEFINED_
extern void bn_createBigHop (void);
#endif 
/* end of file */
/* lines:  */
